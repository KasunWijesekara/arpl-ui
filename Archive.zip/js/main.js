$(function(){
    $('#m_btn').on('click',function(){
        $('#m_menu').sidebar('toggle');
    });

});

$(document).ready(function(){
    $('.demo.menu .item').tab({history:false});
});

$(document).ready(function(){
    $('.demos.menu .item').tab({history:false});
});

$(document).ready(function(){
     $('#AddProducts').click(function(){
        $('#modaldiv').modal('show');    
     });
});


$(document).ready(function(){
     $('#EditProducts').click(function(){
        $('#modaldivedit').modal('show');    
     });
});

// Uid should be added to the ID on the anchor and the js for the modal to work
$(document).ready(function(){
     $('#EditProducts2').click(function(){
        $('#modaldivedit').modal('show');    
     });
});

$(document).ready(function(){
     $('#deleteProduct').click(function(){
        $('#modaldivdelete').modal('show');    
     });
});

$(document).ready(function() {
    $('.ui.dropdown').dropdown();
});