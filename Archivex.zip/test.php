<!-- Modal content is here. and everything is hidden  make sure the proper ID's are added-->
                        <div id="SalesRepEditMod" class="ui modal">
                            <i class="close icon"></i>
                            <div class="header">
                                Add Product Catalogue
                            </div>
                            <div class="content">
                                <div class="ui equal width form">
                                    <div class="fields">
                                        <div class="field">
                                            <label>Name</label>
                                            <input type="text" placeholder="Name">
                                        </div>
                                        <div class="field">
                                            <label>Username</label>
                                            <input type="text" placeholder="Username">
                                        </div>
                                    </div>
                                    <div class="fields">
                                        <div class="field">
                                            <label>Password</label>
                                            <input type="text" placeholder="Password">
                                        </div>
                                        <div class="field">
                                            <label>Contact Number</label>
                                            <input type="text" placeholder="Contact Number">
                                        </div>
                                    </div>
                                    <div class="fields">
                                        <div class="field">
                                            <label>Email</label>
                                            <input type="text" placeholder="Email">
                                        </div>
                                        <div class="field">
                                            <label>Status</label>
                                            <input type="text" placeholder="Status">
                                        </div>
                                    </div>
                                    <div class="fields">
                                        <div class="field">
                                            <label>Sales Target</label>
                                            <input type="text" placeholder="Sales Target">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Modal Buttons  -->
                            <div class="actions" id="modalsbuttons">
                                <div class="ui green button">Submit</div>
                                <!-- <div class="ui red button close">Cancel</div> -->
                            </div>
                        </div>
                        </div><!--  Modal End  -->